/*
 * print_helpers.h
 *
 * Created: 5/25/2019 8:07:20 AM
 *  Author: pvallone
 */ 


#ifndef PRINT_HELPERS_H_
#define PRINT_HELPERS_H_
#include <asf.h>

void print_buffer(uint8_t *buff, uint8_t size);


#endif /* PRINT_HELPERS_H_ */