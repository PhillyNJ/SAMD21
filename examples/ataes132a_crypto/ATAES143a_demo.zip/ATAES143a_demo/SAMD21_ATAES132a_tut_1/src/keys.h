/*
 * keys.h
 *
 * Created: 7/14/2018 6:06:20 AM
 *  Author: pvallone
 */ 


#ifndef KEYS_H_
#define KEYS_H_

extern uint8_t key00[16];
extern uint8_t key01[16];
extern uint8_t key02[16];
extern uint8_t key03[16];
extern uint8_t key04[16];
extern uint8_t key05[16];
extern uint8_t key06[16];
extern uint8_t key07[16];
extern uint8_t key08[16];
extern uint8_t key09[16];
extern uint8_t key10[16];
extern uint8_t key11[16];
extern uint8_t key12[16];
extern uint8_t key13[16];
extern uint8_t key14[16];
extern uint8_t key15[16];
extern uint8_t key_vol[16];
extern uint8_t key_for_load[16];
extern uint8_t key_gen_unlocked[16];

#endif /* KEYS_H_ */